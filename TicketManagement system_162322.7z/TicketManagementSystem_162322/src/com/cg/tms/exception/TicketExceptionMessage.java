package com.cg.tms.exception;

public class TicketExceptionMessage {
	public static final String ERROR1="Enter Description Properly";
	public static final String ERROR2="Enter Priority Properly";

}
