package com.cg.tms.dao;

import java.util.List;
import java.util.Map;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.TicketException;
import com.cg.tms.exception.TicketExceptionMessage;
import com.cg.tms.util.Util;

public class TicketDaoImpl implements TicketDAO {

	@Override
	public Map<String, String> getTicketCategory() {
		// TODO Auto-generated method stub
		return Util.getTicketCategory();
	}

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) throws TicketException {
		if(ticketBean.getTicketDescription()==null)
		{
			throw new TicketException(TicketExceptionMessage.ERROR1);
		}
		if(ticketBean.getTicketPriority()==null)
		{
			throw new TicketException(TicketExceptionMessage.ERROR2);
		}
		return true;
	}

	@Override
	public List<TicketCategory> listTicketPriority() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean addDetails(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		return Util.addDetails(ticketBean);
	}

}
