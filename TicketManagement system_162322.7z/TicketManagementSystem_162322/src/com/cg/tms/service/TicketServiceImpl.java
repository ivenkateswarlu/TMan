package com.cg.tms.service;

import java.util.List;
import java.util.Map;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDaoImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.TicketException;

public class TicketServiceImpl implements TicketService {
	
	TicketDAO dao=new TicketDaoImpl();

	@Override
	public Map<String, String> getTicketCategory() {
		// TODO Auto-generated method stub
		return dao.getTicketCategory();
	}

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) throws TicketException {
		// TODO Auto-generated method stub
		
		return dao.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketPriority() {
		// TODO Auto-generated method stub
		return dao.listTicketPriority();
	}

	@Override
	public boolean validate(TicketBean ticketBean) {
		boolean isValid=true;
		if(ticketBean.getTicketPriority()==null){
			isValid=false;
		}
		if(ticketBean.getTicketDescription()==null){
			isValid=false;
		}
		return isValid;
	}

	@Override
	public boolean addDetails(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		return dao.addDetails(ticketBean);
	}


	

}
