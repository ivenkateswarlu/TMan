package com.cg.tms.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class TicketServiceImplTest {
	private static TicketService clientService = null;

	@BeforeClass
	public static void createInstance() {
		clientService = new TicketServiceImpl();
	}

	private double result1;

	@Test
	public void testForDescripNotNull() {
		TicketBean bean=new TicketBean(null, null, null, null, null, null);
		bean.setTicketDescription(" NotNull");
		boolean result=false;
		result=clientService.validate(bean);
		assertFalse(result);
		
		
	
	}
	/*@Test(expected=TicketException.class)
	public void testForDescriptionNull() throws TicketException
	{
		TicketBean bean=new TicketBean(null, null, null, null, null, null);
		bean.setTicketDescription(" ");
		boolean result=false;
		result=clientService.validate(bean);
		assertFalse(result);
		}
		
		*/
	
	
	@Test
	public void testForTicketPriority() {
		TicketBean bean=new TicketBean(null, null, null, null, null, null);
		bean.setTicketPriority("1");
		boolean result=false;
		result=clientService.validate(bean);
		assertFalse(result);
		
		
	
	}
	@Test
	public void testForTicketPriorityvalue() {
		TicketBean bean=new TicketBean(null, null, null, null, null, null);
		bean.setTicketPriority("a");
		boolean result=false;
		result=clientService.validate(bean);
		assertFalse(result);
		
		
	
	}
	@Test
	public void testForTicketPrioritysymbols() {
		TicketBean bean=new TicketBean(null, null, null, null, null, null);
		bean.setTicketPriority("*");
		boolean result=false;
		result=clientService.validate(bean);
		assertFalse(result);
	}
}
