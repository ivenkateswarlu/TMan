package com.cg.tms.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		
		TicketService service=new TicketServiceImpl();
		Map<String,String> ticketCategory=service.getTicketCategory();
		
		while(true){
			TicketBean ticketBean=new TicketBean(null, null, null, null, null, null);
			System.out.println("Welcome to ITIMD Help Desk.");
			System.out.println("1.Raise Ticket");
			System.out.println("2.Exit from the system");
			Scanner scanner=new Scanner(System.in);	
			int option=scanner.nextInt();
			switch (option) {
			case 1:
				try {
					boolean isValid=service.raiseNewTicket(ticketBean);
				} catch (TicketException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				}
				System.out.println("Select Ticket Category from below List:");
				      int count=1;
				      for(Map.Entry<String, String> entrySet:ticketCategory.entrySet() ){
				    	  System.out.println(count + " . " + entrySet.getValue());
							count++;
				      }
				      int choice=scanner.nextInt();
				      int count1 = 1;
						for (Map.Entry<String, String> entrySet : ticketCategory.entrySet()) {
							if (choice == count1) {
								ticketBean.setTicketCategoryId(entrySet.getKey());

							}
							count1++;
						}
				      System.out.println("Enter Description related to issue");
				      scanner.nextLine();
				      String reason=scanner.nextLine();
				      ticketBean.setTicketDescription(reason);
				System.out.println("Enter Priority(1.low 2.medium 3.high)");
				String opt=scanner.nextLine();
				ticketBean.setTicketPriority(opt);
				double id=(int) (Math.random()*10000);
			int ticketId=(int)id;
				ticketBean.setId(ticketId);
				//List<TicketCategory> priorityList=service.getTicketCategory();
				LocalDateTime ldt=LocalDateTime.now();
				DateTimeFormatter dt=DateTimeFormatter.ofPattern("dd  MMMM  yyyy    hh mm a");
				 String date =ldt.format(dt);
				 ticketBean.setDate(date);
				/*if(service.validate(ticketBean)){
					service.addDetails(ticketBean);
					System.out.println("Details are Stored");
				}
				else{
					System.out.println("Details Not Stored");
				}*/
				
				System.out.println("Ticket Number  "+  ticketBean.getId() +   "logged successfully at"  +ticketBean.getDate());
				
				
				
				break;
            case 2:
            	System.exit(0);
				
				break;

			default:System.out.println("Please enter valid options");
				break;
			}
			
		}
		

	}

}
